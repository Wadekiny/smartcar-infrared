#ifndef _UART_H_
#define _UART_H_

void SendChar(unsigned char dat);
void SendStr(unsigned char *string);
void UartInit();

#endif