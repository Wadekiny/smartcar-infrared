#ifndef __INITS_H
#define __INITS_H

void InitAll();
void PidInit();
void T0Init();

#endif