#ifndef _PWM_H_
#define _PWM_H_
void PwmInit();
void LeftSet(unsigned char set);
void RightSet(unsigned char set);
#endif