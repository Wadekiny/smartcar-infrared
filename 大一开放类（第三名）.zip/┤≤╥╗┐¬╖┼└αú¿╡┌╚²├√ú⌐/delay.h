#ifndef _DELAY_H_
#define _DELAY_H_
//包括调用时间

void Delay20us();
void Delay100us();
void Delay500us();
void Delay1ms();
void Delay10ms();
void Delay100ms();
void Delay500ms();
void Delay1s();
void DelayMs(unsigned int n);

#endif